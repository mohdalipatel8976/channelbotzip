#import os
class Config(object):
    API_ID = 28723446
    API_HASH = "99c6dc17560ac32678fe67012374fe38"
    ASSISTANT_BOT_TOKEN = "7931578516:AAGWDqPvvy3K1wQocMqXHmL81PNqYYm6XsA"
    BOT_TOKEN = "8025591839:AAGkD04urD15kKytN_5wVvk8zCqsPzbHPRc"
    #MONGO_DB_URI = "mongodb://localhost:27017/telegram_bot"

    MONGO_DB_URI = "mongodb+srv://mohdalipatel8976:newPassWord@cluster1.su7cd.mongodb.net/ChannelLogger?retryWrites=true&w=majority"
    LOGGER_ID = -1002325983691 #LOGs group ID here
    DATA_CHANNEL_ID = -1002423482430 #A channel in which add assitant and main bot
    AUTH_USERS = [5943733965, 5732773323]




#2WsCDZSLYDhBfVSu

#ChannelLogger?retryWrites=true&w=majority
