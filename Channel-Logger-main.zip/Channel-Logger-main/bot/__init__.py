import pyroaddon
import tgcrypto

from pyrogram import Client

from bot.config import Config
from bot.functions.database import dataBase
from bot.functions.functions import functionS

mainBot = Client(
    "Main Bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    plugins=dict(root="bot.plugins"),
)

assistantBot = Client(
    "Assistant Bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.ASSISTANT_BOT_TOKEN,
)

mongoDB = dataBase(Config.MONGO_DB_URI)
functions = functionS(mainBot, assistantBot, mongoDB, Config)

sudoList: list[int] = []
chatList: list[int] = []