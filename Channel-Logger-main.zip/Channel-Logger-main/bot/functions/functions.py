import asyncio

from pyrogram import Client
from pyrogram.types import Message, User, ChatJoinRequest
from pyrogram.enums import ChatMemberStatus
from pyrogram.errors import UserNotParticipant, ChatAdminRequired, UserNotParticipant
from bot.functions.database import dataBase
from bot.config import Config

class functionS:
    def __init__(
        self, client: Client, assistant: Client, mongoDB: dataBase, Config: Config
    ):
        self.client = client
        self.assistant = assistant
        self.db = mongoDB
        self.config = Config
        self.default_welcome = "**Hello {0}, welcome to {1}. thanks to join our channel!**"
        self.default_goodbye = "**Hello {0}, why did you left {1} ?**"

    async def is_assistant_in_channel(self, channel_id: int|str) -> tuple:
        try:
            member = await self.assistant.get_chat_member(channel_id, "me")
            try:
                if (
                    member.status == ChatMemberStatus.ADMINISTRATOR
                    and member.privileges.can_change_info
                    and member.privileges.can_manage_chat
                    and member.privileges.can_restrict_members
                ):
                    return (True, None)
                return (False, "__Bot is Admin in Channel but don't have Change Info and Ban Rights!__")
            except:
                return (False, "__checking failed! please remove and add bot again into the Channel__")
        except UserNotParticipant:
            return (False, "__Please Add bot in channel and try again!__")
        except ChatAdminRequired:
            return (False, "__Please Add bot in channel with admin rights and try again!__")
        except Exception as error:
            return (False, f"**Unknown Error:** __{str(error)}__ \n\n__Please Contact to Support!__")

    async def is_user_owner(self, channel_id: int|str, user_id: int) -> tuple:
        if user_id in self.config.AUTH_USERS:
            return (True, None)
        try:
            member = await self.assistant.get_chat_member(channel_id, user_id)
            try:
                if member.status == ChatMemberStatus.OWNER:
                    return (True, None)
                return (False, "__Only Channel owner can connect channel!__")
            except:
                return (False, "__Checking failed! please remove and add this bot again to the Channel__")
        except UserNotParticipant:
            return (False, "__You're not even in channel!__")
        except ChatAdminRequired:
            return (False, "__Please Add bot in channel with admin rights and try again!__")
        except Exception as error:
            return (False, f"**Unknown Error:** __{str(error)}__ \n\n__Please Contact to Support!__")

    async def convert_seconds_to_time(self, seconds: int) -> str:
            days = seconds // (24 * 3600)
            seconds %= (24 * 3600)
            hours = seconds // 3600
            seconds %= 3600
            minutes = seconds // 60
            seconds %= 60

            time_format = ""
            if days > 0:
                time_format += f"{days}d(s)"
            if hours > 0:
                time_format += f"{hours}hr(s)"
            if minutes > 0:
                time_format += f"{minutes}min(s)"
            if seconds > 0:
                time_format += f"{seconds}sec(s)"

            return time_format.strip()

    async def convert_time_to_seconds(self, time_str: str) -> tuple:
        total_seconds = 0
        if time_str.endswith('d'):
            days = int(time_str[:-1])
            total_seconds += days * 24 * 3600
        elif time_str.endswith('h'):
            hours = int(time_str[:-1])
            total_seconds += hours * 3600
        elif time_str.endswith('m'):
            minutes = int(time_str[:-1])
            total_seconds += minutes * 60
        elif time_str.endswith('s'):
            seconds = int(time_str[:-1])
            total_seconds += seconds
        else:
            return (False, "Error: Invalid time format.")

        if total_seconds > 999 * 60:
            return (False, "Error: Total time exceeds 999 minutes.")

        return (True, total_seconds)

    async def share_welcome(self, message: Message, user: User, channel_id: int) -> None:
        if not await self.db.isByUser(channel_id, user.id):
            return await message.reply(
                f"__Only channel Owner/sudo of {channel_id} can get this welcome message!__"
            )
        wait = await message.reply("processing.......")
        try:
            welcomeMessageID = await self.db.getWelcomeMessageID(channel_id)
            await self.client.copy_message(user.id, self.config.DATA_CHANNEL_ID, int(welcomeMessageID))
            await message.reply(f"__Here is your welcome message for chat {channel_id}__")
        except Exception as er:
            await message.reply(f"**Unknown Error:** __{str(er)}__")
        await wait.delete()

    async def share_goodbye(self, message: Message, user: User, channel_id: int) -> None:
        if not await self.db.isByUser(channel_id, user.id):
            return await message.reply(
                f"__Only channel Owner/sudo of {channel_id} can get this goodbye message!__"
            )
        wait = await message.reply("processing.......")
        try:
            goodbyeMessageID = await self.db.getGoodbyeMessageID(channel_id)
            await self.client.copy_message(user.id, self.config.DATA_CHANNEL_ID, int(goodbyeMessageID))
            await message.reply(f"__Here is your Goodbye message for chat {channel_id}__")
        except Exception as er:
            await message.reply(f"**Unknown Error:** __{str(er)}__")
        await wait.delete()

    async def channel_gcast(
        self, message: Message, user: User, channel_id: int
    ) -> None:
        all_users_list = await self.db.getAllUsers(byChat=channel_id)
        if len(all_users_list) == 0:
            return await message.reply(
                f"__No user for {channel_id} is Bot and Bot's database!__"
            )

        approx_time = await self.convert_seconds_to_time(int(len(all_users_list) * 1))
        wait = await message.reply(f"Gcasting to all {len(all_users_list)} users of {channel_id} \n\n__it'll take approx {approx_time} to complete your gcast__")
        await self.assistant.send_message(
            self.config.LOGGER_ID,
            f"GCAST \n\n by - {user.mention} \n - channel: {channel_id}"
        )
        success = 0
        failed = 0
        gcast_forward = await message.reply_to_message.forward(self.config.DATA_CHANNEL_ID)
        gcast_message = await self.assistant.get_messages(self.config.DATA_CHANNEL_ID, int(gcast_forward.id))
        for user in all_users_list:
            try:
                await gcast_message.forward(user['uID'])
                success += 1
                await asyncio.sleep(1)
            except:
                failed += 1
        await wait.reply(
            f"**Successfully Broadcast** \n\n -> Success: {success} \n -> Failed: {failed}"
        )
        await wait.delete()

    async def force_gcast(self, message: Message) -> None:
        all_users_list = await self.db.getAllUsers(inAssistant=True)
        approx_time = await self.convert_seconds_to_time(int(len(all_users_list) * 1))
        wait = await message.reply(f"Force gcasting to all {len(all_users_list)} users of bot \n\n__it'll take approx {approx_time} to complete your gcast__")
        success = 0
        failed = 0
        gcast_forward = await message.reply_to_message.forward(self.config.DATA_CHANNEL_ID)
        gcast_message = await self.assistant.get_messages(self.config.DATA_CHANNEL_ID, int(gcast_forward.id))
        for user in all_users_list:
            try:
                await gcast_message.forward(user['uID'])
                success += 1
                await asyncio.sleep(1)
            except:
                failed += 1
        await wait.reply(
            f"**Successfully Forcecast** \n\n -> Success: {success} \n -> Failed: {failed}"
        )
        await wait.delete()

    async def approve_request(self, chatjoin: ChatJoinRequest) -> None:
        approval_delay = await self.db.getApprovalDelay(chatjoin.chat.id)
        await asyncio.sleep(approval_delay)

        try:
            await chatjoin.approve()
            if not await self.db.isUser(chatjoin.from_user.id):
                await self.db.addUser(chatjoin.from_user.id, chatjoin.from_user.id, True)

            if not await self.db.getWelcomeBefore(chatjoin.chat.id):
                welcome_message_id = await self.db.getWelcomeMessageID(chatjoin.chat.id)
                if not welcome_message_id:
                    return
                try:
                    await self.assistant.copy_message(
                        chatjoin.from_user.id,
                        self.config.DATA_CHANNEL_ID,
                        welcome_message_id
                    )
                except:
                    await self.assistant.send_message(
                        chatjoin.from_user.id,
                        self.default_welcome
                    )
        except Exception as error:
            await self.client.send_message(
                self.config.LOGGER_ID,
                f"**ERROR while apporing request of user {chatjoin.from_user.mention} in chat {chatjoin.from_user.id}*** \n\n{error}"
            )
