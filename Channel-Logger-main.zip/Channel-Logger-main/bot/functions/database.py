import motor.motor_asyncio

class dataBase:
    def __init__(self, db_uri: str):
        self.db_client = motor.motor_asyncio.AsyncIOMotorClient(db_uri)
        self.db = self.db_client["ChannelLogger"]

    # --------- --------- --------- --------- #

    async def addUser(
            self, uID: int, byChat: int = None, inAssistant: bool = False
        ) -> None:
        await self.db.users.insert_one(
            {
                "uID": uID,
                "isSudo": False,
                "byChat": byChat,
                "inAssistant": inAssistant,
            }
        )

    async def isUser(self, uID: int) -> bool:
        return bool(await self.db.users.find_one({"uID": uID}))

    async def getUser(self, uID: int) -> dict:
        return await self.db.users.find_one({"uID": uID})

    async def getAllUsers(
        self, sudo: bool = False, byChat: int = None, inAssistant: bool = False,
    ) -> list[dict]:
        if sudo:
            user_list = self.db.users.find({"isSudo": True})
            return [user async for user in user_list]

        if byChat:
            user_list = self.db.users.find({"byChat": byChat})
            return [user async for user in user_list]

        if inAssistant:
            user_list = self.db.users.find({"inAssistant": True})
            return [user async for user in user_list]

        user_list = self.db.users.find({})
        return [user async for user in user_list]

    async def getTotalUsers(self, inAssistant: bool = False) -> int:
        if inAssistant:
            return await self.db.users.count_documents({"inAssistant": inAssistant})
        return await self.db.users.count_documents({})

    async def setSudo(self, uID: int, key: bool = True) -> None:
        await self.db.users.update_one({"uID": uID}, {"$set": {"isSudo": key}})

    async def isSudo(self, uID: int) -> bool:
        sudo = await self.db.users.find_one({"uID": uID})
        return sudo["isSudo"]

    # --------- --------- --------- --------- #

    async def addChannel(self, chatID: int, byUser: int) -> None:
        await self.db.channels.insert_one(
            {
                "chatID": chatID,
                "byUser": byUser,
                "welcomeMessageID": None,
                "goodbyeMessageID": None,
                "approvalDelay": 10,
                "welcomeBefore": True,
            }
        )

    async def removeChannel(self, chatID: int) -> None:
        await self.db.channels.delete_one({"chatID": chatID})

    async def removeAllChannel(self, byUser: int) -> None:
        await self.db.channels.delete_many({"byUser": byUser})

    async def isChannel(self, chatID: int) -> bool:
        return bool(await self.db.channels.find_one({"chatID": chatID}))

    async def getChannel(self, chatID: int) -> dict:
        return await self.db.channels.find_one({"chatID": chatID})

    async def getAllChannels(self, byUser: int = None) -> list[dict]:
        if byUser:
            channel_list = self.db.channels.find({"byUser": byUser})
            return [channel async for channel in channel_list]

        channel_list = self.db.channels.find({})
        return [channel async for channel in channel_list]

    async def getTotalChannels(self, byUser: int = None) -> int:
        if byUser:
            return await self.db.channels.count_documents({"byUser": byUser})
        return await self.db.channels.count_documents({})

    async def isByUser(self, chatID: int, byUser: int) -> bool:
        return bool(await self.db.channels.find_one({"chatID": chatID, "byUser": byUser}))

    async def getByUser(self, chatID: int) -> int:
        info = await self.db.channels.find_one({"chatID": chatID})
        return info["byUser"]

    async def getWelcomeMessageID(self, chatID: int) -> int:
        info = await self.db.channels.find_one({"chatID": chatID})
        return info["welcomeMessageID"]

    async def getGoodbyeMessageID(self, chatID: int) -> int:
        info = await self.db.channels.find_one({"chatID": chatID})
        return info["goodbyeMessageID"]

    async def getApprovalDelay(self, chatID: int) -> int:
        info = await self.db.channels.find_one({"chatID": chatID})
        return info["approvalDelay"]

    async def getWelcomeBefore(self, chatID: int) -> float:
        info = await self.db.channels.find_one({"chatID": chatID})
        return info["welcomeBefore"]

    async def setWelcomeMessageID(self, chatID: int, welcomeMessageID: int) -> None:
        await self.db.channels.update_one(
            {"chatID": chatID},
            {"$set": {"welcomeMessageID": welcomeMessageID}}
        )

    async def setGoodbyeMessageID(self, chatID: int, goodbyeMessageID: int) -> None:
        await self.db.channels.update_one(
            {"chatID": chatID},
            {"$set": {"goodbyeMessageID": goodbyeMessageID}}
        )

    async def setApprovalDelay(self, chatID: int, approvalDelay: int) -> None:
        await self.db.channels.update_one(
            {"chatID": chatID},
            {"$set": {"approvalDelay": approvalDelay}}
        )

    async def setWelcomeBefore(self, chatID: int, welcomeBefore: bool) -> None:
        await self.db.channels.update_one(
            {"chatID": chatID},
            {"$set": {"welcomeBefore": welcomeBefore}}
        )