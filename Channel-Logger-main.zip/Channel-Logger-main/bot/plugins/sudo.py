from pyrogram import Client, filters
from pyrogram.types import Message

from bot import sudoList, functions

@Client.on_message(
    filters.private & filters.command("mychannel") #& filters.user(sudoList)
)
async def add_channel(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    try:
        chat_arg = str(message.command[1])
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /mychannel (your channel ID or username) \n\n__NOTE: bot don't support links! and please add bot as admin into channel before seting channel.__"
        )

    total_channels = await functions.db.getTotalChannels(message.from_user.id)
    if total_channels >= 20:
        return await message.reply(
            "__You already have 20 channels! you cannot add more!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    isCheck, checkMessage = await functions.is_assistant_in_channel(chat_arg)
    if isCheck:
        isOwner, checkReply = await functions.is_user_owner(chat_arg, message.from_user.id)
        if not isOwner:
            await message.reply(checkReply)
            return await wait.delete()

        chat_info = await functions.assistant.get_chat(chat_arg)
        if await functions.db.isChannel(chat_info.id):
            await message.reply(
                f"__{chat_info.title} already in connect list!__"
            )
            return await wait.delete()

        await functions.db.addChannel(chat_info.id, message.from_user.id)
        await message.reply(
            f"**Added {chat_info.title} (`{chat_info.id}`) into Logger!** \n\n__Please set your approval (default: 20 secs.) delay, welcome and goodbye message!__"
        )
        await bot.send_message(
            functions.config.LOGGER_ID,
            f"**CHANNEL ADDED** \n\n - By: {message.from_user.mention} \n - Channel: {chat_info.title} (`{chat_info.id}`)"
        )
    else:
        await message.reply(checkMessage)
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("mychannels") #& filters.user(sudoList)
)
async def list_channel(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    channel_list = await functions.db.getAllChannels(message.from_user.id)
    if len(channel_list) == 0 or not channel_list:
        return await message.reply(
            f"__You have 0 channels connected!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    channel_message = "**Here is list of all connected channels** \n\n"
    for idx, channel in enumerate(channel_list, start=1):
        try:
            channel_info = await functions.assistant.get_chat(channel['chatID'])
            channel_message += f"**{idx}.** {channel_info.title} (`{channel_info.id}`) \n"
        except:
            channel_message += f"**{idx}.** `{channel['chatID']}` \n"

        delay = await functions.convert_seconds_to_time(int(channel['approvalDelay']))
        view_welcome = f"https://t.me/{bot.me.username}?start=welcome_{channel['chatID']}"
        view_goodbye = f"https://t.me/{bot.me.username}?start=goodbye_{channel['chatID']}"
        channel_message += f"  - Delay: {delay} | [view welcome]({view_welcome}) | [view goodbye]({view_goodbye}) \n\n"

    channel_message += f"__You have total {len(channel_list)} channels connected!__"
    await message.reply(channel_message, disable_web_page_preview=True)
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("removemychannel") #& filters.user(sudoList)
)
async def remove_channel(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    try:
        channel_id = int(message.command[1])
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /removemychannel (your channel ID) \n\n__NOTE: bot don't support links or username!.__"
        )

    if not await functions.db.isChannel(channel_id):
        return await message.reply(
            f"__channel {channel_id} not in database!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    if (
        (await functions.db.isByUser(channel_id, message.from_user.id))
        or message.from_user.id in functions.config.AUTH_USERS
    ):
        await functions.db.removeChannel(channel_id)
        await message.reply(
            f"**Channel {channel_id} successfully removed from connect list!**"
        )
    else:
        await message.reply(
            f"**You cannot removed {channel_id} channel from connect list!**"
        )
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("approvetime") #& filters.user(sudoList)
)
async def set_approvetime(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    try:
        channel_id = int(message.command[1])
        approve_delay = str(message.command[2])
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /approvetime (your channel ID) (approve time) [use s for seconds, m for min and h for hours] \nExample Use: /approvetime -100123456789 3m - by this bot will save approve time of 3 mins \n\n__NOTE: bot don't support links or username!.__"
        )

    is_converte, approve_seconds = await functions.convert_time_to_seconds(approve_delay)
    if not is_converte:
        return await message.reply(is_converte)

    if not await functions.db.isChannel(channel_id):
        return await message.reply(
            f"__channel {channel_id} not in database!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    if (
        (await functions.db.isByUser(channel_id, message.from_user.id))
        or message.from_user.id in functions.config.AUTH_USERS
    ):
        await functions.db.setApprovalDelay(channel_id, approve_seconds)
        await message.reply(
            f"**Successfully updated approve time for {channel_id} as {approve_delay} ({approve_seconds}secs.)**"
        )
    else:
        await message.reply(
            f"**You cannot edit {channel_id} channel settings!**"
        )
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("setwelcome") #& filters.user(sudoList)
)
async def set_welcome(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    if not message.reply_to_message:
        return await message.reply(
            "Please reply to your welcome message and enter the command -> /setwelcome (channel id)"
        )

    try:
        channel_id = int(message.command[1])
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /setwelcome (your channel ID) while replying your welcome message. \n\n__NOTE: bot don't support links or username!.__"
        )

    if not await functions.db.isChannel(channel_id):
        return await message.reply(
            f"__channel {channel_id} not in database!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    if (
        (await functions.db.isByUser(channel_id, message.from_user.id))
        or message.from_user.id in functions.config.AUTH_USERS
    ):
        welcome_message = await message.reply_to_message.copy(functions.config.DATA_CHANNEL_ID)
        await functions.db.setWelcomeMessageID(channel_id, welcome_message.id)
        view_url = f"https://t.me/{bot.me.username}?start=welcome_{channel_id}"
        await message.reply(
            f"**Successfully updated welcome message for {channel_id} -> [view]({view_url})**",
            disable_web_page_preview=True
        )
    else:
        await message.reply(
            f"**You cannot edit {channel_id} channel settings!**"
        )
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("before") #& filters.user(sudoList)
)
async def set_before(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    try:
        channel_id = int(message.command[1])
        process = str(message.command[2]).lower()
        if process not in ["yes", "no"]:
            return await message.reply(
                "__Before can be 'yes' or 'no'__"
            )
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /before (your channel ID) ('yes' | 'no') \n\n__NOTE: bot don't support links or username!. Yes stands to send welcome message before approve.__"
        )

    if not await functions.db.isChannel(channel_id):
        return await message.reply(
            f"__channel {channel_id} not in database!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    if (
        (await functions.db.isByUser(channel_id, message.from_user.id))
        or message.from_user.id in functions.config.AUTH_USERS
    ):
        if process == "yes":
            await functions.db.setWelcomeBefore(channel_id, True)
            await message.reply(
                f"**Now I'll send welcome message beforing approving join request of chat {channel_id}**"
            )
        else:
            await functions.db.setWelcomeBefore(channel_id, False)
            await message.reply(
                f"**Now I'll send welcome message after approving join request of chat {channel_id}**"
            )
    else:
        await message.reply(
            f"**You cannot edit {channel_id} channel settings!**"
        )
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("setgoodbye") #& filters.user(sudoList)
)
async def set_goodbye(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    if not message.reply_to_message:
        return await message.reply(
            "Please reply to your goodbye message and enter the command -> /setgoodbye (channel id)"
        )

    try:
        channel_id = int(message.command[1])
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /setgoodbye (your channel ID) while replying your goodbye message. \n\n__NOTE: bot don't support links or username!.__"
        )

    if not await functions.db.isChannel(channel_id):
        return await message.reply(
            f"__channel {channel_id} not in database!__"
        )

    wait = await message.reply("processing, please wait for few sec........")
    if (
        (await functions.db.isByUser(channel_id, message.from_user.id))
        or message.from_user.id in functions.config.AUTH_USERS
    ):
        goodbye_message = await message.reply_to_message.copy(functions.config.DATA_CHANNEL_ID)
        await functions.db.setGoodbyeMessageID(channel_id, goodbye_message.id)
        view_url = f"https://t.me/{bot.me.username}?start=goodbye_{channel_id}"
        await message.reply(
            f"**Successfully updated goodbye message for {channel_id} -> [view]({view_url})**",
            disable_web_page_preview=True
        )
    else:
        await message.reply(
            f"**You cannot edit {channel_id} channel settings!**"
        )
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("gcast") #& filters.user(sudoList)
)
async def sudo_gcast(bot: Client, message: Message):
    if message.from_user.id not in sudoList:
        return

    if not message.reply_to_message:
        return await message.reply(
            "Please reply to your gcast message and enter the command -> /gcast (channel id)"
        )

    try:
        channel_id = int(message.command[1])
    except:
        return await message.reply(
            f"**INVALID CMD** \n\nSyntax: /gcast (your channel ID) while replying your gcast message. \n\n__NOTE: bot don't support links or username!.__"
        )

    if not await functions.db.isChannel(channel_id):
        return await message.reply(
            f"__channel {channel_id} not in database!__"
        )

    if (
        (await functions.db.isByUser(channel_id, message.from_user.id))
        or message.from_user.id in functions.config.AUTH_USERS
    ):
        await functions.channel_gcast(message, message.from_user, channel_id)
    else:
        await message.reply("**You cannot gcast in others channel!**")