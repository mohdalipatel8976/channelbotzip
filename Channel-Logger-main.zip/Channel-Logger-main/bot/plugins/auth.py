from pyrogram import Client, filters
from pyrogram.types import Message

from bot import functions, sudoList


@Client.on_message(
    filters.command("stats") & filters.user(functions.config.AUTH_USERS)
)
async def stats(_, message: Message):
    wait = await message.reply("fetching.....")
    stats = "**Bot's Current stats!** \n\n"
    total_users = await functions.db.getTotalUsers()
    total_users_assis = await functions.db.getTotalUsers(inAssistant=True)
    total_channels = await functions.db.getTotalChannels()

    stats += f"__ -> Total Users:__ {total_users} \n"
    stats += f"__ -> Total Users (Assistant):__ {total_users_assis} \n"
    stats += f"__ -> Total Users:__ {total_channels}"

    await message.reply(stats)
    await wait.delete()

@Client.on_message(
    filters.command("addsudo") & filters.user(functions.config.AUTH_USERS)
)
async def add_sudo(bot: Client, message: Message):
    try:
        user_base = str(message.command[1])
        try:
            user = await bot.get_users(user_base)
        except Exception as er:
            return await message.reply(
                f"ERROR: {str(er)}"
            )
    except:
        return await message.reply(
            "**INVALID COMMAND:** syntax -> /addsudo (username or id) - only valid users whos starts the bot!"
        )

    if not await functions.db.isUser(user.id):
        return await message.reply(
            "__Please tell them to start me!__"
        )

    if await functions.db.isSudo(user.id):
        if user.id not in sudoList:
            sudoList.append(user.id)
        return await message.reply(
            f"__user {user.mention} already in sudo list!__"
        )

    await functions.db.setSudo(user.id, True)
    if user.id not in sudoList:
        sudoList.append(user.id)
    await message.reply(
        f"**Added {user.mention} as sudo**"
    )

@Client.on_message(
    filters.command("removesudo") & filters.user(functions.config.AUTH_USERS)
)
async def remove_sudo(bot: Client, message: Message):
    try:
        user_base = str(message.command[1])
        try:
            user = await bot.get_users(user_base)
        except Exception as er:
            return await message.reply(
                f"ERROR: {str(er)}"
            )
    except:
        return await message.reply(
            "**INVALID COMMAND:** syntax -> /addsudo (username or id) - only valid users whos starts the bot!"
        )

    if not await functions.db.isUser(user.id):
        return await message.reply(
            "__Please tell them to start me!__"
        )

    if await functions.db.isSudo(user.id):
        await functions.db.setSudo(user.id, False)
        if user.id in sudoList:
            sudoList.remove(user.id)
        await message.reply(
            f"**Removed {user.mention} from sudo**"
        )
    else:
        if user.id in sudoList:
            sudoList.remove(user.id)
        return await message.reply(
            f"__user {user.mention} not in sudo list!__"
        )

@Client.on_message(
    filters.command("listsudo") & filters.user(functions.config.AUTH_USERS)
)
async def list_sudo(bot: Client, message: Message):
    if len(sudoList) == 0:
        return await message.reply(
            "__No sudo users in Bot!__"
        )

    wait = await message.reply("fetching.....")
    sudo_message = "**Sudo List!** \n\n"
    for idx, sudo_id in enumerate(sudoList, start=1):
        try:
            sudo = await bot.get_users(sudo_id)
            sudo_message += f"**{idx}:** {sudo.mention} (`{sudo.id}`) \n"
        except:
            sudo_message += f"**{idx}:** `{sudo_id}` \n"

    await message.reply(sudo_message)
    await wait.delete()

@Client.on_message(
    filters.private & filters.command("forcecast") & filters.user(functions.config.AUTH_USERS)
)
async def forcecast(_, message: Message):
    if not message.reply_to_message:
        return await message.reply(
            "Please reply to your gcast message and enter the command -> /gcast (channel id)"
        )

    await functions.force_gcast(message)