from pyrogram import Client, filters
from pyrogram.types import Message

from bot import sudoList, functions


START_MESSAGE = """
**Hello {0}**
"""

@Client.on_message(
    filters.private & filters.command("start")
)
async def start(_, message: Message):
    user = message.from_user
    if not await functions.db.isUser(user.id):
        await functions.db.addUser(user.id)

    if len(message.command) > 1:
        deep_text = str(message.command[1])
        if (
            (deep_text.startswith("welcome")
            or deep_text.startswith("goodbye"))
            and "_" in deep_text
        ):
            try:
                channel_id = int(deep_text.split("_")[1])
            except:
                return await message.reply("__Invalid Channel ID__")

            if await functions.db.isChannel(channel_id):
                if deep_text.startswith("welcome"):
                    return await functions.share_welcome(message, user, channel_id)
                return await functions.share_goodbye(message, user, channel_id)

    if user.id in sudoList:
        await message.reply(START_MESSAGE.format(user.mention))
    else:
        await message.reply(
            f"__Hello {user.mention}, how are you ?__"
        )