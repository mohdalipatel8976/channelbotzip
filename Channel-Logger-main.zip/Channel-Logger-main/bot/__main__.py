import asyncio

from pyrogram import filters, idle
from pyrogram.types import Message, ChatMemberUpdated, ChatJoinRequest
from pyrogram.enums import ChatMemberStatus

from bot import functions, mainBot, assistantBot, sudoList, chatList


# --------- Logger --------- #
@assistantBot.on_message(
    filters.private & filters.command("start")
)
async def assistant_start(_, message: Message):
    if not await functions.db.isUser(message.from_user.id):
        await functions.db.addUser(message.from_user.id, inAssistant=True)

    await message.reply(
        f"__Hello {message.from_user.mention} it's {assistantBot.me.mention}__"
    )

@assistantBot.on_chat_join_request()
async def auto_approve(_, chatjoin: ChatJoinRequest):
    if chatjoin.chat.id not in chatList:
        return

    if await functions.db.getWelcomeBefore(chatjoin.chat.id):
        welcome_message_id = await functions.db.getWelcomeMessageID(chatjoin.chat.id)
        if not welcome_message_id:
            return
        try:
            await functions.assistant.copy_message(
                chatjoin.from_user.id,
                functions.config.DATA_CHANNEL_ID,
                welcome_message_id
            )
        except:
            await functions.assistant.send_message(
                chatjoin.from_user.id,
                functions.default_welcome.format(
                    chatjoin.from_user.mention, chatjoin.chat.title
                )
            )
        if not await functions.db.isUser(chatjoin.from_user.id):
            await functions.db.addUser(chatjoin.from_user.id, chatjoin.from_user.id, True)
    asyncio.create_task(functions.approve_request())

@assistantBot.on_chat_member_updated()
async def leave_message(_, chat_member_updated: ChatMemberUpdated):
    if chat_member_updated.chat.id not in chatList:
        return

    if chat_member_updated.old_chat_member and chat_member_updated.old_chat_member.status in [ChatMemberStatus.LEFT, ChatMemberStatus.MEMBER]:
        goodbye_message_id = await functions.db.getGoodbyeMessageID(chat_member_updated.chat.id)
        if not goodbye_message_id:
            return
        try:
            await functions.assistant.copy_message(
                chat_member_updated.from_user.id,
                functions.config.DATA_CHANNEL_ID,
                goodbye_message_id
            )
        except:
            await functions.assistant.send_message(
                chat_member_updated.from_user.id,
                functions.default_goodbye.format(
                    chat_member_updated.from_user.mention, chat_member_updated.chat.title
                )        
            )

async def main():
    print(" -> starting the bot.....")
    await mainBot.start()
    await assistantBot.start()
    print(f" -> Started both bot as @{mainBot.me.username} & @{assistantBot.me.username} (assistant)")

    print(" -> Loading sudo list & channels.....")
    db_sudos = await functions.db.getAllUsers(sudo=True)
    sudoList.extend([sudo['uID'] for sudo in db_sudos])
    print(" -> Loaded Sudos....")
    db_chats = await functions.db.getAllChannels()
    chatList.extend([chat['chatID'] for chat in db_chats])
    print(" -> Loaded All chats!")
    print(" -> Bot is Alive!")
    await idle()

    print(" -> Bot stopped, all process stopped!")
    await mainBot.stop()
    await assistantBot.stop()

if __name__ == "__main__":
    mainBot.run(main())
